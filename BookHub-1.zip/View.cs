using System;
using System.Collections.Generic;

static class View 
{
  //CRUDS para livros, autores e categorias
  public static void CadastrarLivro(string nome, int anolanc, int paginas, float preco, int nota, int idautor, int idcategoria){
    if (preco < 0) throw new ArgumentOutOfRangeException("Preço inválido");
    if (nota < 0 || nota > 100) throw new ArgumentOutOfRangeException("Nota inválida");
    if (anolanc < 0) throw new ArgumentOutOfRangeException("Ano de lançamento inválido");
    if (paginas < 0) throw new ArgumentOutOfRangeException("Páginas inválidas");
    Livro l = new Livro{Nome = nome, AnoLanc = anolanc, Paginas = paginas, Preco = preco, Nota = nota};
    NLivro nl = new NLivro();
    nl.Inserir(l);
  }

  
  public static List<Livro> ListarLivros(){
    NLivro np = new NLivro();
    return np.Listar();
  }

  
  public static void AtualizarLivro(int idLivro, string titulo, int ano, int paginas, float preco, int nota, int aut, int cat){
    Livro l = new Livro{Id = idLivro, Nome = titulo, AnoLanc = ano, Paginas = paginas, Preco = preco, Nota = nota};
    NLivro nl = new NLivro();
    nl.Atualizar(l);
  }

  
  public static void RemoverLivro(int idLivro){
    Livro l = new Livro{Id = idLivro};
    NLivro nl = new NLivro();
    nl.Excluir(l);
  }





  
  
  public static void CadastrarAutor(string nome, int anonasc, string nacionalidade){
    if(nome.Length < 3 || nome.Length > 25) throw new ArgumentOutOfRangeException("Nome inválido");
    if(anonasc < 0) throw new ArgumentOutOfRangeException("Ano de nascimento inválido");
    if(nacionalidade.Length < 3 || nacionalidade.Length > 25) throw new ArgumentOutOfRangeException("Nacionalidade inválida");
    Autor a = new Autor{Nome = nome, Anonasc = anonasc, Nacionalidade = nacionalidade};
    NAutor na = new NAutor();
    na.Inserir(a);
  }
  
  public static List<Autor> ListarAutores(){
    NAutor na = new NAutor();
    return na.Listar();
  }

  
  public static void AtualizarAutor(int idautor, string nome, int anonasc, string nacionalidade){
    NAutor na = new NAutor();
    Autor a = new Autor{Id = idautor, Nome = nome, Anonasc = anonasc, Nacionalidade = nacionalidade};
    na.Atualizar(a);
  }
  
  public static void RemoverAutor(int idAutor){
    NAutor na = new NAutor();
    Autor a = na.Listar(idAutor);
    na.Excluir(a);
  }





  

  public static void CadastrarCategoria(string nome, string descricao){
    if(nome.Length > 50 || nome.Length < 3) throw new ArgumentOutOfRangeException("Nome da categoria inválido");
    if(descricao.Length > 200 || descricao.Length < 3) throw new ArgumentOutOfRangeException("Descrição da categoria inválida");
    Categoria cat = new Categoria{Nome = nome, Descricao = descricao};
    NCategoria nc = new NCategoria();
    nc.Inserir(cat);
  }

  
  public static List<Categoria> ListarCategorias(){
    NCategoria nc = new NCategoria();
    return nc.Listar();
  }

  
  public static void AtualizarCategoria(int idcategoria, string nome, string descricao){
    NCategoria nc = new NCategoria();
    Categoria cat = new Categoria{Id = idcategoria, Nome = nome, Descricao = descricao};
    nc.Atualizar(cat);
  }

  
  public static void RemoverCategoria(int idCategoria){
    Categoria c = new Categoria{Id = idCategoria};
    NCategoria nc = new NCategoria();
    nc.Excluir(c);
  }




  

  
  

  public static void CadastrarUsuario(string nome, string email, string senha){
    if(senha.Length < 8) throw new ArgumentOutOfRangeException("Senha inválida");
    Usuario u = new Usuario{Nome = nome, Email = email, Senha = senha};
  }

  
  public static List<Usuario> ListarUsuarios(){
    NUsuario nu = new NUsuario();
    return nu.Listar();
  }

  
  public static void AtualizarUsuario(int idusuario, string nome, string email, string senha){
    NUsuario nu = new NUsuario();
    Usuario u = new Usuario{Id = idusuario, Nome = nome, Email = email, Senha = senha};
    nu.Atualizar(u);
  }

   
  public static void RemoverUsuario(int idUsuario){
    NUsuario nu = new NUsuario();
    Usuario u = nu.Listar(idUsuario);
    nu.Excluir(u);
  }

  public static List<Livro> ListarLivrosFavoritos(int idUsuario){
    NUsuario nu = new NUsuario();
    Usuario u = nu.Listar(idUsuario);
    return u.LivrosFavoritos;
  }

  public static void MarcarLivroFavorito(int idUsuario, int idlivro){
    NUsuario nu = new NUsuario();
    NLivro nl = new NLivro();
    Livro alvo = nl.Listar(idlivro);
    Usuario ualvo = nu.Listar(idUsuario);
    ualvo.LivrosFavoritos.Add(alvo);
    }

  public static void RemoverLivroFavorito(int idUsuario, int idlivro){
    NUsuario nu = new NUsuario();
    NLivro nl = new NLivro();
    Livro alvo = nl.Listar(idlivro);
    Usuario ualvo = nu.Listar(idUsuario);
    ualvo.LivrosFavoritos.Remove(alvo);
  }

  
}